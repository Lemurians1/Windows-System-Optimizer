const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { exec } = require('child_process');

function createWindow() {
  const win = new BrowserWindow({
    width: 600,
    height: 750,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true
    }
  });
  win.loadFile('index.html');
}

app.whenReady().then(createWindow);

ipcMain.handle('run-command', async (_, command) => {
  return new Promise((resolve) => {
    exec(`powershell -Command "${command}"`, { windowsHide: true }, (error, stdout, stderr) => {
      if (error) return resolve({ success: false, message: stderr });
      resolve({ success: true, message: stdout });
    });
  });
});