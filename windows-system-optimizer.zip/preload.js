const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  run: (cmd) => ipcRenderer.invoke('run-command', cmd)
});