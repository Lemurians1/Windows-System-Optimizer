window.addEventListener('DOMContentLoaded', () => {
  const output = document.getElementById('output');
  const progressContainer = document.getElementById('progressContainer');
  const progressBar = document.getElementById('progressBar');
  const statusIcon = document.getElementById('statusIcon');
  const clearedInfo = document.getElementById('clearedInfo');

  const runTask = async (button, prepareCmd, actionCmd) => {
    button.disabled = true;
    statusIcon.style.display = 'none';
    clearedInfo.textContent = '';
    output.textContent = 'Processing...';
    progressContainer.style.display = 'block';
    progressBar.style.width = '30%';

    // Measure before
    const before = await window.api.run(prepareCmd);
    progressBar.style.width = '60%';

    // Perform action
    const res = await window.api.run(actionCmd);
    progressBar.style.width = '90%';

    // Measure after
    const after = await window.api.run(prepareCmd);
    progressBar.style.width = '100%';

    // Calculate cleared
    const beforeSize = parseFloat(before.message) || 0;
    const afterSize = parseFloat(after.message) || 0;
    const clearedMB = ((beforeSize - afterSize) / (1024*1024)).toFixed(2);

    // Update UI
    output.textContent = res.success ? 'Done!' : `Error: ${res.message}`;
    statusIcon.style.display = 'block';
    clearedInfo.textContent = `Cleared ${clearedMB} MB of temp files`;

    setTimeout(() => {
      progressContainer.style.display = 'none';
      progressBar.style.width = '0%';
      button.disabled = false;
    }, 2000);
  };

  const sizeCmd = "(Get-ChildItem -Path $Env:TEMP -Recurse | Measure-Object -Property Length -Sum).Sum";

  document.getElementById('cleanTemp').addEventListener('click', () => {
    runTask(
      document.getElementById('cleanTemp'),
      sizeCmd,
      `Remove-Item -Path $Env:TEMP\\* -Recurse -Force`
    );
  });

  document.getElementById('powerPlan').addEventListener('click', async () => {
    document.getElementById('powerPlan').disabled = true;
    const res = await window.api.run('powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c');
    output.textContent = res.success ? 'High Performance Enabled!' : `Error: ${res.message}`;
    document.getElementById('powerPlan').disabled = false;
  });

  document.getElementById('disableAnimations').addEventListener('click', async () => {
    const cmds = [
      'Set-ItemProperty -Path HKCU:\\Control Panel\\Desktop -Name "DesktopLivePreviewHoverTime" -Value 0',
      'Set-ItemProperty -Path HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced -Name "ListviewAlphaSelect" -Value 0'
    ];
    const res = await window.api.run(cmds.join('; '));
    output.textContent = res.success ? 'Animations Disabled!' : `Error: ${res.message}`;
  });

  document.getElementById('reduceGraphics').addEventListener('click', async () => {
    const res = await window.api.run('Set-ItemProperty -Path HKCU:\\Control Panel\\Desktop -Name LogPixels -Value 96');
    output.textContent = res.success ? 'Graphics Scaled to 100%!' : `Error: ${res.message}`;
  });
});